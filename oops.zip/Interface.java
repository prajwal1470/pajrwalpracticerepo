package Oopsconcepts;


////  WHAT IS INTERFACE?
/// classes implement an interface and provide the actual code for its method
/// method declarations (methods without bodies
/// key points
/// * partly implement is not possible 
/// * we cant create constructor in interface 
/// * we will create overloaded method 
/// wed cant create method overriding 
/// we cant able to use the super keyword 

