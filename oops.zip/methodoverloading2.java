package Oopsconcepts;
class you 
{
	int add (int x, int y)
	{
	return (x+y);
	}
}
class me extends you
{
	int add (int x, int y)
	{
		return (x+y);
	}
}
class to extends me 
{
	int add (int x, int y)
	{
		return (x+y);
	}
}
public class methodoverloading2 {
public static void main (String [] args)
{
	me obj = new me ();
	System.out.println(obj.add(10, 10));
	System.out.println(obj.add(20,20));
	
	to obj1 = new to();
	System.out.println(obj1.add(30, 30));
}
}
