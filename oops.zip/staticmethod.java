package Oopsconcepts;       //// what is static method ?
                            ////// we access the directly by the class level by using the classname.methodname.
class mnc
{
	static void run()
	{
		System.out.println("hello");
	}
	static void test()
	{
		System.out.println("hi");
	}
}
public class staticmethod {

	public static void main(String[] args) {
		mnc.run();
		mnc.test();
	}

}
