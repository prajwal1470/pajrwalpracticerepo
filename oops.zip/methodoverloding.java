package Oopsconcepts;
class kj                      ///// what is compile time polymorphism (method overloading)
{                            ////  same method but diffrent parameter              
	int add(int a, int b)   ///// without return type we cant do method overloading .....
	{                       ///// return type is also diffrent .
		return (a+b);  
	}
	int add(int a, int b,int c)
	{
		return (a+b-c);
	}
	double add(double a, double b, double c)
	{
		return (a+b+c);
	}
	float add (float a, float b , float c)
	{
		return (a+b+c);
	}
}   

public class methodoverloding {

	public static void main(String[] args) {
		kj obj=new kj ();
		System.out.println(obj.add(10, 10));
		System.out.println(obj.add(20, 10, 20));
		System.out.println(obj.add(10d, 10d, 30d));
		System.out.println(obj.add(10f, 10f, 40f));
	}

}
