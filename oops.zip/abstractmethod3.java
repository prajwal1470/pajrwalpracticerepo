package Oopsconcepts;
abstract class pp
{
void main ()
{
	System.out.println("hello");
}
abstract void main1();
abstract void test();
abstract void message ();

}

class ss extends pp
{
	void main1()
	{
		System.out.println("hi");
	}
	void test ()
	{
		System.out.println("where are you ");
	}
	void message ()
	{
		System.out.println("i am at home ");		}
}
public class abstractmethod3 {
	public static void main (String [] args)
	{
		ss ref = new ss();
		ref.main();
		ref.main1();
		ref.test();
		ref.message();
	}
	

}
