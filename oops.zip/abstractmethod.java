/// what is abstract method ? 
//// important deatils hiding from the non functional one.
/// abstract method only as declaration no body written method over here 
///  we cant use static method inside the abstract method 
/// we cant use final key word inside the abstract method  
/// we can easy apply the method overloading and method overrding inside the abstract method 
/// we can also create  constructor insoide the abstract method                        
/// this key word also can we used 
                       

