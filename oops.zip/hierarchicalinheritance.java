package Oopsconcepts;
class aaa      //// what is heriachical inheritance?
{              //// 2 different child classes inherit the same parent classes.
	void run()     ///// or multiple child classes inherit the same parent classes.
	{
		System.out.println("hi");
	}
}
class aa2 extends aaa
{
	void test()
	{
		System.out.println("hello");
	}
}
class aa3 extends aaa
{
	void message ()
	{
		System.out.println("where are you");
	}
}
public class hierarchicalinheritance {

	public static void main(String[] args) {
	aa2 obj = new aa2();
	obj.run();
	obj.test();
	
	aa3 obj1=new aa3();
	obj1.message();

	}

}
