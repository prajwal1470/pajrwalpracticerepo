package Oopsconcepts;
class rr                     //// what is super class?
{                            /// to access the immediate super class using the super key word.
	String name = "prajwal";
}
class rt extends rr
{
	String name ="sandesh";
	void run()
	{
		System.out.println(super.name);
	System.out.println(name);
	}
}
public class superkeyeord {

	public static void main(String[] args) {
		rt obj = new rt();
		obj.run();

	}

}
