package Oopsconcepts;
abstract class ww
{
	void main ()
	{
		System.out.println("hello");
	}
	void test ()
	{
		System.out.println(" hi");
	}
	void message ()
	{
		System.out.println("where are you");
	}
	void run ()
	{
		main();
		test();
		message();
		System.out.println("i am at home ");
	}
	abstract void test1();
	abstract void run1();
}
class zz extends ww
{
	void test1()
	{
		System.out.println("whaty are you doing");
	}
	void run1()
	{
		System.out.println("i am texting");
	}
}

public class abstractmethod4 {

	public static void main(String[] args) {
		zz ref = new zz ();
		ref.run();
		ref.test1();
		ref.run1();

	}

}
