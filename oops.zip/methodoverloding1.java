package Oopsconcepts;

class nc
{
	int add (int d, int e)
	{
		return (d+e);
	}
	int add (int f, int g, int h)
	{
		return (f-g-h);
	}
}
public class methodoverloding1 {
	public static void main (String [] arrgs)
	{
		nc obj = new nc ();
		System.out.println(obj.add(10, 200));
		System.out.println(obj.add(100, 200, 300));
	}

}
