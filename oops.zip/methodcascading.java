package Oopsconcepts;

class aa            /////// what is method cascading ?
{                     ////// calling a multiple method in same object by using a dot operator.
	void test()
	{
		System.out.println("hello");
	}
	void run ()
	{
		System.out.println("hi");
	}
	void message ()
	{
		System.out.println("where are you");
	}
	void display()
	{
		System.out.println("i am at home");
	}
	void call ()
	{
		test();
		run();
		message();
		display();
		System.out.println("at what time you will reaching ");
	}
}
public class methodcascading {

	public static void main(String[] args) {
		aa obj = new aa();
		obj.call();
	

	}

}
