package Oopsconcepts;
class a1       ////  what is single level inheritance?
{              ///    child class inherit the parent class by using extends .
	void test()
	{
		System.out.println("hello");
	}
}
class a2 extends a1
{
	void test1()
	{
		System.out.println("hi");
	}
}

public class singlelevelinheritance {

	public static void main(String[] args) {
		a2 obj =new a2();
	    obj.test();
	    obj.test1();

	}

}
