package Oopsconcepts;
interface p1
{
	void message ();
}
interface s1
{
	void test();
}
class d1 implements p1,s1
{
	public void message ()
	{
		System.out.println("hello");
	}
	public void test ()
	{
		System.out.println("hi");
	}
}
public class interface1 {
	public static void main (String [] args )
	{
		p1 ref = new d1();
		ref.message();
		s1 ref1=new d1();
		ref1.test();
		
	}

}
