package Oopsconcepts;
/// what is encapsulation ? 
/// its rapping warpping the data and method the operate on the data into the single unit
/// (alt+shift+s)

		