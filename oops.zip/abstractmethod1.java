package Oopsconcepts;

abstract class ko
{
	void test()
	{
		System.out.println("hello");
	}
	abstract void run();
	abstract void test1();
}
class kl extends ko
{
	void run()
	{
		System.out.println("hi");
	}
	void test1()
	{
		System.out.println("where are you ");
	}
}
public class abstractmethod1 {
public static void main (String [] args)
{
	kl ref =new kl();
	ref.test();
	ref.run();
	ref.test1();

	
}
}
