package Oopsconcepts;
class hh
{
	int add (int x, int y)
	{
		return (x+y);
	}
}
class hj extends hh
{
	int add(int x, int y) 
	{
		return (x+y);
	}
}
class hg extends hh
{
	int add(int x,int y)
	{
		return (x+y);
	}
}

public class methodoverriding1 {
public static void main (String [] args)
{
	hg obj = new hg();
	System.out.println(obj.add(30, 20));
	System.out.println(obj.add(10, 20));
	
	hj obj1 = new hj();
	System.out.println(obj1.add(10, 20));
}
}
