package Oopsconcepts;  ///// what is this keyword?
                 ///// it mainly used to identify the which is loacal variable and which is instance variable 
class mnz
{
	int id ;
	String name ;
	float salary;
	static String companyname="rnm";
	mnz (int i, String n, float s)
	{
		this.id=i;
		this.name=n;
		this.salary=s;
	}
	void run ()
	{
		System.out.println(id+" "+name +" "+salary+" "+companyname);
	}
}
public class thiskeyword {
	public static void main (String[] args)
	{
		mnz obj =new mnz (178,"prajwal",800f);
		obj.run();
		mnz obj1=new mnz (176,"praju",800f);
		obj1.run();
	}

}
