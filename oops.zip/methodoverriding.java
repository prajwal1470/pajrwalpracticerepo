package Oopsconcepts;      //// what is method overriding or run time polymorphsim.
class ff                   /// same method and same parameter  but they will persent in diffrent classes.
{                          //// return type also same .
  int add(int a , int b)
  {
	  return (a+b);
  }
}
class fd extends ff
{
	int add (int a, int b)
	{
		return (a+b);
	}
}

public class methodoverriding {
	public static void main (String [] args) {
		fd obj = new fd();
		System.out.println(obj.add(200, 100));
		System.out.println(obj.add(200, 200));
	}

}
