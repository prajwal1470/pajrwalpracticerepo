package Oopsconcepts;
abstract class ro
{
	int id;
	String empname;
	ro(int i, String en)
	{
		id=i;
		empname=en;
	}
	void run()
	{
		System.out.println(id+"  "+empname);
	}
	abstract void salary();
	abstract void bloodgroup();
}
class rx extends ro
{
	
	rx(int i, String en)
	{
		super(120,"praju");
		
	}
	void salary()
	{
		System.out.println("30000");
	}
	void bloodgroup()
	{
		System.out.println("onegative");
	}
}

public class abstractmethod2 {
public static void main (String [] args )
{
	rx ref = new rx(0, null);
	ref.run();
	ref.salary();
	ref.bloodgroup();
}
}
