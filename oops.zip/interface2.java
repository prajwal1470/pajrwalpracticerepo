package Oopsconcepts;
interface tt
{
	void run();
	void run1();
}
interface ttt
{
	void test ();
	void test1();
}
class yyy  implements tt,ttt
{
	public void run()
	{
		System.out.println("hello");
	}
	public void run1 ()
	{
		System.out.println("hi");
	}
	public void test()
	{
		System.out.println("where are you ");
	}
	public void test1()
	{
		System.out.println("i am at home ");
	}
}
public class interface2 {
	public static void main (String [] args)
	{
		tt ref = new yyy();
		ref.run();
		ref.run1();
		
		ttt ref1 = new yyy();
		ref1.test();
		ref1.test1();	}

}
