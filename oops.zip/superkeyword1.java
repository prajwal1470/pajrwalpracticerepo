package Oopsconcepts;
class m1
{
	int a=10;
	int b=4;
	int c=(a+b);
}
class m2 extends m1
{
	int a =15;
	int b=1;
	int c=(a-b);
	
	void run ()
	{
		System.out.println(c);
		System.out.println(super.c);
	}
}
public class superkeyword1 {
	
	public static void main (String [] args)
	{
		m2 obj= new m2();
	    obj.run();
	}

}
