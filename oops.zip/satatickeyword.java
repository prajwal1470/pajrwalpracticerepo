package Oopsconcepts;
class mn
{
	int  id;
	String name ;
	float salary;
	mn(int i, String n , float s)
	{
		id=i;
		name=n;
		salary=s;
	}
	static String companyname= "xyz";
	
	void run ()
	{
		System.out.println(id+" "+name+"  " +salary+ " "+companyname);
	}
}

public class satatickeyword {

	public static void main(String[] args) {
		mn obj = new mn(128, "prajwal", 8000f);
	     obj.run();
	     mn obj1 = new mn(127, "rohan", 7200f);
	     obj1.run();
	     mn obj2 = new mn(126, "sandesh", 80000f);
	     obj2.run();
	     mn obj3 = new mn(125, "yashwanth", 8000f);
	     obj3.run();
	}

}
