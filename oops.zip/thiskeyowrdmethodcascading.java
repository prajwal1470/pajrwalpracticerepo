package Oopsconcepts;
class dd
{
	void main ()
	{
		System.out.println("hi");
	}
	void run ()
	{
		System.out.println("hello");
	}
	void test()
	{
		System.out.println("where are you");
	}
	void main1()
	{
		this.main();
		this.run();
		this.test();
		System.out.println("i am at home");
	}
}
public class thiskeyowrdmethodcascading {
	
	public static void main (String [] args)
	{
		dd obj = new dd ();
		obj.main1();
	}

}
