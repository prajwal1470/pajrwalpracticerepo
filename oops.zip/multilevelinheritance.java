package Oopsconcepts;
class a                  ///// what is multilevel inheritance?
{                       ///// one class in inherit the another class , another class inherit from it .
	void run ()         //// grandparent class inherit the parent class , parent class inherit thr chid class.
	{
		System.out.println("hi");
	}
}
class b extends a
{
	void run1()
	{
		System.out.println("hello");
	}
}
class c extends b
{
	void run2()
	{
		System.out.println("where are you");
	}
}
public class multilevelinheritance {
public static void main (String [] args)
{
	c obj = new c();
	obj.run();
	obj.run1();
	obj.run2();
}
}
