package Oopsconcepts;
class max
{
	int id = 127;
     String name="praju";
	 public int getId() {
		 return id;
	 }
	 public String getName() {
		 return name;
	 }
}
public class encapsulation1 {
public static void main (String [] args)
{
	max obj=new max();
	System.out.println(obj.name);
	System.out.println(obj.id);		
	
}
}
