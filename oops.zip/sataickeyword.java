package Oopsconcepts;
class jj
{
	int id;
	String name;
	float salary;
	boolean married;
	static String companyname = "xyz";
	jj(int i , String n, float s, boolean m)
	{
		id=i;
		name=n;
		salary=s;
		married=m;
	}
	static void change ()
	{
		companyname ="mnx";
	}
	void test()
	{
		System.out.println(id+" "+name +" "+ salary+" "+married+" " +companyname);
	}
}
public class sataickeyword {

	public static void main(String[] args) {
		
		jj obj =new jj (1287, "prajwal", 800f , true);
		obj.test();
		jj obj1 =new jj (1286, "sandesh", 800f , true);
		obj1.test();
		jj obj2 =new jj (1285, "rohan", 800f , false);
		obj2.test();
		

	}

}
