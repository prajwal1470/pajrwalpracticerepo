package Oopsconcepts;
class mnx
{
	int id ;
	String name ;
	float salary;
	static String companyname="rnm";
	boolean married;
	mnx (int i, String n, float s)
	{
		this.id=i;
		this.name=n;
		this.salary=s;
	}
	mnx (int i ,String n, float s, boolean m)
	{
		this (i,n,s);
		this.married=m;
	}
	void run ()
	{
		System.out.println(id+" "+name +" "+salary+" "+companyname+" "+married);
	}
}
public class thiskeyword1 {

	public static void main(String[] args) {
		{
			mnx obj =new mnx (178,"prajwal",800f);
			obj.run();
			mnx obj1=new mnx (176,"praju",800f , true);
			obj1.run();
		}

	}

}
