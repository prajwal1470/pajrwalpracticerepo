package Looping;

public class ifstatment {

	public static void main(String[] args) {
		int age =18;
		if (age >=18)
		{
			System.out.println("they have a voting power");
		}

	}

}
