package Looping;
 /// what is looping?
 /// looping is a set of statment exute a progaram reptedly based on the condition
 /// 
 /// types of looping ?
 /// * while loop
 /// * do whileloop
 /// *for loop
 /// *for each loop
 /// *nested for loop
