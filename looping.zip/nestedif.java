package Looping;

public class nestedif {
	
	public static void main (String [] args)
	{
		int age = 25;
		if (age <=17)
		{
			System.out.println("they are not eligiable to vote");
		}
		if (age>=18)
		{
			System.out.println(" they are eligiable to vote");
		}
		if (age>=60)
		{
			System.out.println(" a represenative will come home to take a vote");
		}
		if (age>=75)
		{
			System.out.println(" they will arrage the online voting protle to vote");
		}
	}

}
