package Looping;

public class nestedif1 {
	public static void main (String [] args)
	{
		int age=19;
		if (age>=15)
		{
			System.out.println("they will eligable to take 10th exam");
		}
		if (age>=18)
		{
			System.out.println(" they will eligable to take 2nd puc exam");
		}
		if (age==19)
		{
			System.out.println("they will eligable to take CET exam");
		}
		if (age>=21)
		{
			System.out.println("they will eligable to take degree exam");
		}
	}

}
