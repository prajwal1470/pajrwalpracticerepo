package Looping;       //// what is while loop?
                     //// while loop is also called as entry control loop
public class whileloop {    
public static void main (String [] args)
{
	int i = 5;
	while (i<=8) 
	{
		System.out.println(i); 
		i++;
	}
}
}
