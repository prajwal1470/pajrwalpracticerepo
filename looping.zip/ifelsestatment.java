package Looping;

public class ifelsestatment {
	
	public static void main (String [] args)
	{
		int age = 21;
		if (age>=18)
		{
			System.out.println("they are  eligiable to vote");
		}
		else 
		{
			System.out.println("they are not eligiable to vote");
		}
	}

}
