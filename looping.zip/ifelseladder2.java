package Looping;

public class ifelseladder2 {
	public static void main (String [] args)
	{
		int babyage=4;
		if (babyage==3)
		{
			System.out.println("take a admission for daycare");
		}
		else if (babyage==4)
		{
			System.out.println("take a admission for perkg");
		}
		else if (babyage==5)
		{
			System.out.println("take a admission for 1st standred");
		}
		else if (babyage==6)
		{
			System.out.println("take a admission for 2nd standred");
		}
	}

}
