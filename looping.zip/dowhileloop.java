package Looping;   /// what is mean by do while loop?
                    //// dowhile loop is called exit control loop.
public class dowhileloop {
public static void main(String [] args)
{
	int i=5;
	do
	{
		System.out.println(i);
		i++;
	}
	while (i<=8);
}
}
