package Looping;
/// what is conditional statment?
/// conditional statemnt helps the program choose what to do next depending on some condition.
/// or conditional statment means that run the progam based on the some conditions
///
/// types of conditional statment in java ?
////if statment .
/// if else statment .
////if else ladder statment .
/// nested if  statment.
/// nested if else statment.
