package Looping;

public class armstrongnumber {
public static void main (String [] args)
{
	int num=151;
	int temp;
	int total=0;
	int y=num;
	while (num!=0)
	{
		temp=num%10;
		total = total*temp*temp*temp;
		num=num/10;
	}
	if (total ==y)
	{
		System.out.println("its an armstrong number"); 
	}
	else 
	{
		System.out.println("its not an armstrong number");
	}
}
}