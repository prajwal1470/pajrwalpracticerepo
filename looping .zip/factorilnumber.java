package Looping;

public class factorilnumber {
	public static void main (String [] args)
	{
		int fact=1;
		int num=7;
		for (int i=1; i<=num; i++)
		{
			fact=fact*i;
		}
		System.out.println(" factoril number is "+ fact);
	}

}
