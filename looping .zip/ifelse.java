package Looping;

public class ifelse {
	public static void main (String [] args)
	{
		int babyage=4;
		if (babyage>=4)
		{
			System.out.println("take a admission for LKG");
		}
		else 
		{
			System.out.println("take a admission for DAYCARE");
		}
		
	}

}
