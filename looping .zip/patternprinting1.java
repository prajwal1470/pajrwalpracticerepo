package Looping;

public class patternprinting1 {
	public static void main (String [] args)
	{
		int num=15;
		int row, coloum;
		for (row=0 ; row<num ;row++)
		{
			for (coloum=0 ;coloum<=row ; coloum++)
			{
				System.out.print(" * ");
			}
				System.out.println(  );
		}
	}

}
