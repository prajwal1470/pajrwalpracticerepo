package Looping;

public class sumofallnumbers3 {
	public static void main (String [] args)
	{
      int num=89;
      int sum=0;
      int i=1;
      do
      {
    	  sum+=i;
    	  i++;
      }
      while(i<=num);
      {
    	  System.out.println("sum is"+sum);
      }
}
}
