package Looping;

public class reverse1 {
	public static void main (String [] args )
	{
		int num = 777;
		int rev=0;
		int y=num;
		while (num!=0)
		{
			int n = num%10;
			rev=rev*10+n;
			num=num/10;
		}
		System.out.println(rev);
		if (y==rev)
		{
			System.out.println("its a palindrome ");
		}
		else 
		{
			System.out.println("it is not a palindrome ");
		}
	}
}
