package Looping;

public class reversenumber4 {
	public static void main (String [] args)
	{
	int num =8888;
	int x=num;
	int rev=0;
	while(num!=0)
	{
		int n=num%10;
		rev=rev*10+n;
		num=num/10;
	}
	{
		System.out.println(rev);
	}
	if (x==rev)
	{
		System.out.println("its is an palindrome");
	}
	else 
	{
		System.out.println("its is not an palindrome");
	}
	}

}
