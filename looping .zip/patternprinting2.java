package Looping;

public class patternprinting2 {
	public static void main (String [] args)
	{
		int num=15;
		int i,j;
		for (i=0; i<=num; i++)
		{
			for (j=0; j<=i; j++)
			{
				System.out.print(" * ");
			}
			System.out.println();
		}
	}

}
