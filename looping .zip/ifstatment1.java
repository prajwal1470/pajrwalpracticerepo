package Looping;

public class ifstatment1 {
	public static void main (String[] args)
	{
		int a = 10;
		if (a>=9);
		{
			System.out.println("yes");
		}
	}

}
