package Looping;

public class armstrongnumber1 {
public static void main (String [] args)
{
	int num=153;
	int temp;
	int total=0;
	int r=num;
	while (num!=0)
	{
		temp=num%10;
        total=total+temp*temp*temp;
        num=num/10;
	}
	{
		System.out.println(total);
		if (total==r)
		{
			System.out.println("its an armstrong number");
		}
		else 
		{
			System.out.println("its not an armstrong number");
		}
	}
}
}
