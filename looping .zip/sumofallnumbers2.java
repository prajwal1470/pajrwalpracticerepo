package Looping;

public class sumofallnumbers2 {
public static void main (String [] args)
{
	int n=100;
	int sum=0;
	int i=1;
	do
	{
		sum+=i;
		i++;
	}
	while (i<=n);
	{
		System.out.println("sum is "+sum);
	}
}
}
