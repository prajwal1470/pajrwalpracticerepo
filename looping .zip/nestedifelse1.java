package Looping;

public class nestedifelse1 {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=30;
		if (a>b)
		{
			if (a>c)
			{
				System.out.println("a max");
			}
			else
			{
				System.out.println("c max");
			}
		}
			else 
			{
				if (b>c)
				{
					System.out.println("b max");
				}
				else 
				{
					System.out.println("c max ");
				}
			}
			
		}

}
