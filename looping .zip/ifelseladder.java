package Looping;

public class ifelseladder {
	public static void main (String [] args)
	{
		int marks=30;
		if (marks >=90)
		{
			System.out.println("Garde A");
		}
		else if (marks >=80)
		{
			System.out.println("Grade B");
		}
		else if (marks >=70)
		{
			System.out.println("Grade c");
		}
		else if (marks <=35)
		{
			System.out.println("Fail");
		}
	}

}
