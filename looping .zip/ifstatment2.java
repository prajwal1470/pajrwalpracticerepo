package Looping;

public class ifstatment2 {
	public static void main(String [] args)
	{
		int babyage=3;
		if (babyage>=3)
		{
			System.out.println("take a admission for DAYCARE");
		}
	}

}
