package Looping;

public class reverse {
	public static void main (String [] args)
	{
		int num=111;
		int e=num;
		int rev=0;
		while (num!=0)
		{
			int w=num%10;
			rev=rev*10+w;
			num=num/10;
		}
		{
			System.out.println(rev);
		}
		if (e==rev)
		{
			System.out.println("this number is palindrome");
		}
		else
		{
			System.out.println("this number is not palindrome");
		}
	}

}
