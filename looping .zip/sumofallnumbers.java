package Looping;

public class sumofallnumbers {

	public static void main(String[] args) {
		int m=13;
		int sum=0;
		int i=1;
		do
		{
			sum+=i;
			i++;
		}
		while(i<=m);
		{
			System.out.println("sum is"+sum);
		}

	}

}
