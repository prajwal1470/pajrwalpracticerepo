package Looping;
///// since the result is equal to the original number is known as armstrong number
public class armstrongnumber2 {    
	public static void main (String [] args)
	{
		int num=258;
		int n=num;
		int temp;
		int total=0;
	    while (num!=0)
	    {
	    	temp=num%10;
	    	total=total+temp*temp*temp;
	    	num=num/10;
	    }
	    System.out.println(total);
	    if (total==n)
	    {
	    	System.out.println("it is an armstrong number");
	    }
	    else
	    {
	    	System.out.println("it is not an armstrong number");
	    }
	}

}
