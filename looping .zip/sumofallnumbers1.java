package Looping;

public class sumofallnumbers1 {
	public static void  main(String [] args)
	{
		int n=11;
		int sum=0;
		int i=1;
		do
		{
			sum+=i;
			i++;
		}
		while(i<=n);
		{
			System.out.println("sum is "+sum);
		}
	}

}
