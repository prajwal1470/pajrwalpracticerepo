package Looping;

public class patternprinting {
	public static void main (String [] args)
	{
		int num=25;
		int i;
		int j;
		for (i=0; i<num; i++)
		{
			for (j=0; j<=i; j++)
			{
				System.out.print(" * ");
			}
			System.out.println();
		}
		
	}

}
