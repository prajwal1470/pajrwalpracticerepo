package Looping;

public class reversenumber2 {

	public static void main(String[] args) 
	{
		int num=567;
		int rev=0;
		int u=rev;
		while (num!=0)
		{
			int u1=num%10;
			rev=rev*10+u1;
			num=num/10;
		}
		{
			System.out.println(rev);
		}
		if (num==u)
		{
			System.out.println("it is palindrom");
		}
		else 
		{
			System.out.println("it is not palindrom");
		}
	}
}
