package Looping;

public class reversenumber3 {
public static void main (String [] args)
{
	int num=123;
	int rev=0;
	int r =num;
	while (num!=0)
	{
		int r1=num%10;
		rev=rev*10+r1;
		num=num/10;
	}
	{
		System.out.println(rev);
		if (r==rev)
		{
			System.out.println(" its an palindrom");
		}
		else 
		{
			System.out.println("its not an palindrom");
		}
	}
}
}
