package Operators;

public class arithmeticoperators1 {

	public static void main(String[] args) {
		int a = 30;
		int b=50;
		int c=20;
		int d=a+b-c;
		System.out.println(d);

	}

}
