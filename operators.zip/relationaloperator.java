package Operators;

class relationaloperator {
	
	public static void main (String [] args)
	{
		int a = 10;
		int b= 50;
		System.out.println(a<b);
	}

}
