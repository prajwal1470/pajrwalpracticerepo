package Operators;

public class realtionaloperator3 {

	public static void main (String [ ] args)
	{
		int a=100;
		int b=90;
		System.out.println(a==b);
	}
	
}
