package Operators;

public class assignmentoperator {
	
	public static void main (String [] args)
	{
		int a=50;
		int b=60;
		int c=a+b+60;
		System.out.println(c);
	}
}
