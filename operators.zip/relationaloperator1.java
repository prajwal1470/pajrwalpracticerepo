package Operators;

public class relationaloperator1 {
	
	public static void main (String [] args)
	{
		int a = 10 ;
		int b = 2;
		System.out.println(b>a);
	}

}
