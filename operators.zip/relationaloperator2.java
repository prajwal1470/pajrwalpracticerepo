package Operators;

public class relationaloperator2 {
	
	public static void main (String [] args)
	{
		int a = 10;
		int b = 2;
		System.out.println(a>=b);
	}

}
