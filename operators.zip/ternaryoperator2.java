package Operators;

public class ternaryoperator2 {

	public static void main(String[] args) {
		int a = 50;
		int b = 30;
		int c=80;
		int d= a>b?(a>c?a:c):(b>c?b:c);
		System.out.println(d);
				

	}

}
