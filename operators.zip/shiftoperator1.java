package Operators;

public class shiftoperator1 {
	
	public static void main ( String [] args)
	{
		int a = 16;
		System.out.println(a>> 3);      /// right shift operator works a/2 power n
	}

}
