package Operators;

public class assignmentoperator2 {

	public static void main(String[] args) {
		int a = 20;
		int b= 30;
		int c=45;
		int d=a+b+c+45;
		System.out.println(d);

	}

}
