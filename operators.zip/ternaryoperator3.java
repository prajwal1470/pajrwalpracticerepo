package Operators;

public class ternaryoperator3 {

	public static void main(String[] args) {
		int  a=30;
		 int b=40;
		 int min = a<b?a:b;
		 System.out.println(min);
	}

}
