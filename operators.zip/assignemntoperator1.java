package Operators;

public class assignemntoperator1 {
	public static void main (String [] args)
	{
		int a = 82;
		int b=52;
		int c=100;
		int d=150;
		int ch = a+b+c+d;
		System.out.println(ch);
		
	}

}
