package Operators;

class logicaloperator1 {
	
	public static void main (String [] args)
	{
		int a = 150 ;
		int b = 100;
		if (a<155 & b>99)
		System.out.println(true);
		else 
			System.out.println(false);
	}

}
