package Operators;

class unaryopertors1 {
	
	public static void main (String [] args)
	{
		int a = 500 ;
		int b ;
		b = ++ a;
		System.out.println(b);
	}

}
