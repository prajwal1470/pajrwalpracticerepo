package Operators;

class logicaloperator {
 public static void main (String [] args)
 {
	 int a = 10;
	 int b = 20;
	 

   if (a >=10 & b>15)
   System.out.println(true);
   else
   System.out.println(false);
 }
}
