package Operators;

public class shiftoperator {
	
	public static void main (String [] args)
	{
		int a = 10;
		System.out.println(a<<10);         ///// left shift operator a x 2 power 10
		                                                              
	}

}
