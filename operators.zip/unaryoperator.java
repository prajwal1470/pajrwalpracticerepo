package Operators;

public class unaryoperator {
public static void main (String [] args)
{
	int a = 100;
	int b;
	b = a ++;
	System.out.println(b);
}
}
