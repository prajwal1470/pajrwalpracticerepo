package Operators;

public class ternaryoperator1 {

	public static void main(String[] args) {
		int a = 50;
		int b= 30;
		int c= 60;
		int d = a>b ? (a>c?a:c):(b>c?b:c);
		System.out.println(d);
	}

}
