package methods;
class a4
{
	int id;
	String name ;
	float salary;
	boolean married;
	a4(int i,String n,float s, boolean m)
	{
		id=i;
		name =n;
		salary=s;
		married=m;
	}
	void message ()
	{
		System.out.println(id + " "+name +"  "+salary+"  "+married);
	}
}

public class parametziedconstructor {
	
		public static void main (String [] args)
		{
			a4 obj1 =new a4(7895 , "praju" , 8000f, false);
		    obj1.message ();
		    
			a4 obj =new a4(7895 , "prajwal" , 8000f ,true);
		    obj.message ();
		
		}
	
	
	

}
