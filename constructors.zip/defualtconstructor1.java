package methods;
class a2
{
	a2()
	{
		System.out.println("hi");
	}
	
	{
		System.out.println("hello");
	}
	void test()
	{
		System.out.println("where are you");
	}
}
public class defualtconstructor1 {

	public static void main(String[] args) {
		a2 obj = new a2();
		obj.test();
	

	}

}
