package methods;

class TVS
{
	int productid ;
	String productname ;
	float productrate;
	TVS(int pi , String pn , float pr)
	{
		productid=pi;
		productname=pn;
		productrate=pr;
	}
	void message()
	{
		System.out.println(productid+""+productname+""+productrate);
	}
}
public class parametziedconstructor1 {
	public static void main (String[] args)
	{
    TVS obj = new TVS(125," nut ", 15f);
    obj.message();
	}

}
