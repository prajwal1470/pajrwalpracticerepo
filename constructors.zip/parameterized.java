package methods;
class a3
{
	int id;
	String name ;
	float salary;
	a3(int i, String n , float s)
	{
		id=i;
		name =n;
		salary=s;
	}
	void test()
	{
		System.out.println(id + "   "+name +"  "+salary);
	}
}

public class parameterized {

	public static void main(String[] args) {
		
	
		a3 obj=new a3(7828, "prjwal" ,8000f);
		obj.test();
	
	}

}
