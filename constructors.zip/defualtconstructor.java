package methods;
class a1
{
	void test()
	{
		System.out.println("hello");
	}
}

public class defualtconstructor {

	public static void main(String[] args) {
		a1 obj =new a1 ();
		obj.test();

	}

}
