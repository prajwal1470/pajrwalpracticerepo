package Assignment;
class shapes {
	
	double length;
	
	shapes(double length)
	{
		this.length=length;
	}

void square()
{
	double area = length*length;
	System.out.println("area of square="+area);
}
void rectangle()
{
	double breadth=length;
	double area= length*breadth;
	System.out.println("area of rectangle="+area);
}
void circle()
{
	double area=3.14*length*length;
	System.out.println("area of circle="+area);
}
public class qp24 {
	public static void mian(String [] args)
	{
		shapes obj=new shapes(10);
		obj.square();
		obj.rectangle();
		obj.circle();
	}
}		
}


