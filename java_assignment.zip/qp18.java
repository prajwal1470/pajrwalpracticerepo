package Assignment;
interface Transport
{
	void booking ();
}
class Bus implements Transport
{
	public void booking ()
	{
     System.out.println("we will get the tickets in the Bus stop"); 
	}
	
}
class Flight implements Transport
{
	public void booking ()
	{
     System.out.println("we have to book the tickets 3 dyas before"); 
	}
	
}

public class qp18 {

	public static void main(String[] args) 
	{
     Transport ref = new Flight ();
     ref.booking();
     Transport ref1 = new Bus ();
     ref1.booking();
     

	}

}
