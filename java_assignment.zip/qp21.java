package Assignment;

class university
{
	static String country= "india";
	String universityname;
	
	university(String u )
	{
	universityname=u;
	}
	
	void run()
	{
		System.out.println(country+ " " +universityname );
	}
}

public class qp21 {

	public static void main(String[] args) 
	{
		university u =new university("vtu university");
		u.run();
		university u1 =new university("bombay university");
		u1.run();
		university u2 =new university("mysore university");
		u2.run();
		university u3 =new university("delhi university");
		u3.run();

	}

}
