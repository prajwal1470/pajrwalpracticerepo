package Assignment;

class vehicle 
{
	void fueltype()
	{
		System.out.println("RUNS ON FUEL");
	}
}
class electriccar extends vehicle 
{
	void fueltype()
	{
		System.out.println("RUNS ON electricity");
	}
}
public class qp2 {

	public static void main(String[] args) {
		
		electriccar e =new electriccar();
		e.fueltype();
		vehicle v =new vehicle();
		v.fueltype();
		

	}

}
