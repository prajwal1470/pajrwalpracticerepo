package Assignment;
class course
{
	void courseInfo() 
	{
	System.out.println("GrowSkills IT");
	}
}
class science extends course
{
	void courseInfo1() 
	{
	System.out.println("its cover physics, chemistry, biology.");
	}
}
class commerce extends course
{
	void courseInfo2() 
	{
	System.out.println("its consits bussiness study,accountncy,ecnomics.");
	}
}
class arts extends course
{
	void courseInfo3()
	{
	System.out.println("its completly get the guide  history , geogarphy, constitution.");
	}
}
public class qp14 {

	public static void main(String[] args) 
	{
	science s=new science();
	s.courseInfo();
	s.courseInfo1();
	
	
	commerce c=new commerce();
	c.courseInfo2();
	
	arts a=new arts();
	a.courseInfo3();
	

	}

}
