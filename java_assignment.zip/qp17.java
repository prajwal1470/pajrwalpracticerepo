package Assignment;
abstract class employee
{
	abstract void cacluatesalary();
	
	int Employeeid ;
	String Employeename;
	
	employee(int Employeeid ,String Employeename)
	{
		this.Employeeid=Employeeid;
		this.Employeename=Employeename;
	}
	void employeedeatils ()
	{
		System.out.println(Employeeid +" "+ Employeename);
	}	
}
class fulltimeemployee extends employee
{	


	fulltimeemployee(int Employeeid, String Employeename) 
	{
		super(Employeeid, Employeename);
	}
	int employeesalary=10000;
	void cacluatesalary()
	{
		System.out.println(Employeeid+" " +Employeename+ " "+ employeesalary);
	}
}
class parttimeemployee extends employee
{
	parttimeemployee(int Employeeid, String Employeename) 
	{
		super(Employeeid, Employeename);
		
	}
	int employeesalary=5000;
	void cacluatesalary()
	{
		System.out.println(Employeeid+" " +Employeename+ " "+ employeesalary);
	}
}
public class qp17 {
	public static void main(String [] args)
	{
		fulltimeemployee f=new fulltimeemployee(123, "prajwal");
		f.cacluatesalary();
		
		parttimeemployee p=new parttimeemployee(158, "sandesh");
		p.cacluatesalary();
	}

}
