package Assignment;
class student 
{
  int rollno;
  String studentname;
  static String collegename = "BGSIT";
  student(int r,String s)
  {
  rollno=r;
  studentname=s;
  }
  void main () 
  {
  System.out.println(rollno+"    "+studentname +"   "+ collegename);
  }
}

public class qp10 {

	public static void main(String[] args) 
	{
	student a= new student (56789,"PRAJWAL");
	a.main();
	student a1= new student (56789,"SANDESH");
	a1.main();
	student a2= new student (56789,"PUNIEETH");
	a2.main();
	student a3= new student (56789,"RAMPRASAD");
	a3.main();
     }

}
