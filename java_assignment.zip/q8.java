package Assignment;
class shape
{
	double area (double pi, double length ,double width)
	{
		
		return pi*length*width;
	}
}
class rectangle extends shape
{
	double area (double length, double width)
	{
		return length*width;
	}
}
class circle extends shape
{
	double area(double pi,double radius)
	{	
		return pi*radius*radius;
	}
}
public class q8 {
public static void main (String [] args)
{
	circle c=new circle();
	System.out.println(c.area(3.14 ,5 ));
	rectangle r=new rectangle();
	System.out.println(r.area(10 , 20));
	shape s=new shape ();
	System.out.println(s.area(3.14, 15 , 20));
	
	
	
}
}
