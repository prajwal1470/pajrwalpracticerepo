package Assignment;
class loancalculator
{
	int calculateloan (int loan)
	{
		return (loan);
	}
	double calculateloan (int loan , double rateofintrest)
	{
		return (loan*rateofintrest);
	}
}
public class qp15 {

	public static void main(String[] args) 
	{
		loancalculator l= new loancalculator();
		System.out.println(l.calculateloan(200000));
		System.out.println(l.calculateloan(200000,  3.5f));

	}

}
