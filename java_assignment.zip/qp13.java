package Assignment;

class device
{
	void start()
	{
	System.out.println("device is turning on");
	}
}
class mobile extends device 
{
	void calling()
	{
	System.out.println("dailing contact number");
	}
}
class smartphone extends mobile
{
	void internet()
	{
	System.out.println("connect the internet to the phone");
	}
}
public class qp13 {
	
	public static void main(String[] args) {
		smartphone s=new smartphone ();
		s.start();
		s.calling();
		s.internet();
		
	}

}
