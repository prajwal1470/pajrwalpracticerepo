package Assignment;
abstract class animal 
{
	abstract void sound();
}
class dog extends animal 
{
    void sound ()
    {
    	System.out.println("bow bow");
    }
}
class cat extends animal 
{
	void sound()
	{
		System.out.println("meaw meaw");
	}
}
public class qp5 {
	public static void main (String [] args)
	{
		animal ref =new cat ();
		ref.sound();
		animal ref1 =new dog ();
		ref1.sound ();
	}

}
