package Assignment;
interface payment 
{
	void makepayment();
}
class upi implements payment
{
    public void makepayment()
	{
		System.out.println("show the scanner ");
	}
    
}
class creditcard implements payment
{
	public void makepayment()
	{
		System.out.println("swip the card");
	}
}
public class qp6 {

	public static void main(String[] args) {
	payment ref = new creditcard ();
	ref.makepayment();
	payment ref1 = new upi();
	ref1.makepayment();

	}

}
