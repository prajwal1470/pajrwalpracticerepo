package Assignment;

class hospital 
{
	
	void emergencyservice()
	{
	System.out.println("hospital needs a ambluance");
	}
}
class cityhospital extends hospital 
{
	void emergencyservice()
	{
		
		System.out.println("cityhospital needs a another doctor immedilty");
		super.emergencyservice();
	}
}
public class qp16 {
	
	public static void main (String [] args)
	{
		cityhospital c=new cityhospital();
		c.emergencyservice();
		
		
	}

}
