package Assignment;
class person
     {
     String Created= "Person Created";
     }
class Student extends person
{
	String Created= "Student Created";

	void main () 
	{
		
	System.out.println(Created);
	System.out.println(super.Created);
	}
	
}
public class qp7 {
	public static void main(String[] args) 
	{	
		Student  s=new Student();
		s.main();
	}

}
