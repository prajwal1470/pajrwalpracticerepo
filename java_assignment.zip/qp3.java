package Assignment;
class product
{
	int productid;
	String productname;
	float productprice;
	product(int productid , String productname , float productprice)
	{
		this.productid=productid;
		this.productname=productname;
		this.productprice=productprice;	
	}
	void displayproduct()
	{
		System.out.println("product created");
		
		System.out.println(productid+" "+ productname+" "+productprice);
	}
		
	
}
	public class qp3 {
	public static void main(String[] args) 
	{
		
	product p= new product( 152, "macair1", 85000f);
	p.displayproduct();
	
	product p1= new product(153, "macair2", 95000f);
	p1.displayproduct();
	
	product p2= new product(154, "macair3", 105000f);
	p2.displayproduct();
	}

}
