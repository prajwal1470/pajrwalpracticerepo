package Assignment;
class libray
{
	String librayname ;

libray ()
{
	System.out.println("welocme to the  libray");
}
void showlocation ()
{
	System.out.println("This libray located in Mumbai");
}
public class qp11 {
	public static void main (String[] args) {
		 
		libray l=new libray();
		l.showlocation();	
	}
	
}
}
