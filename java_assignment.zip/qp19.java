package Assignment;
class camera
{
	void capture()
	{
		System.out.println("its not clear picture than dslr");
	}
}
class dslrcamera extends camera
{
	void capture() 
	{
		System.out.println("awesome pic");
	}
}
public class qp19 {
	
	public static void main(String [] args)
	{
		camera c =new dslrcamera();
		c.capture();
		
	}

}
